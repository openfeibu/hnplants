<?php

return array(

    'DR_UPDATE'		=> '2017.7.26',
    'DR_VERSION'	=> '5.0.11',
);
