<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-07 09:24:54 --> Unable to connect to the database
ERROR - 2017-08-07 15:44:08 --> Query error: Can't DROP 'shenghuoxing'; check that column/key exists - Invalid query: ALTER TABLE `fn_1_news` DROP `shenghuoxing`
ERROR - 2017-08-07 15:44:29 --> Query error: Can't DROP 'shidileixing'; check that column/key exists - Invalid query: ALTER TABLE `fn_1_news` DROP `shidileixing`
ERROR - 2017-08-07 15:45:43 --> Query error: Can't DROP 'wslx'; check that column/key exists - Invalid query: ALTER TABLE `fn_1_news` DROP `wslx`
ERROR - 2017-08-07 15:45:56 --> Query error: Can't DROP 'gstx'; check that column/key exists - Invalid query: ALTER TABLE `fn_1_news` DROP `gstx`
ERROR - 2017-08-07 15:46:09 --> Query error: Can't DROP 'jixiang'; check that column/key exists - Invalid query: ALTER TABLE `fn_1_news` DROP `jixiang`
ERROR - 2017-08-07 15:47:19 --> Query error: Can't DROP 'ssfw'; check that column/key exists - Invalid query: ALTER TABLE `fn_1_news` DROP `ssfw`
ERROR - 2017-08-07 15:47:23 --> Query error: Can't DROP 'qihouleixing'; check that column/key exists - Invalid query: ALTER TABLE `fn_1_news` DROP `qihouleixing`
ERROR - 2017-08-07 17:51:04 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:51:08 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:51:08 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:51:11 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:51:12 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:51:13 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:20 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:24 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:28 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:55 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:55 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:56 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:56 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:56 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:57 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:57 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:58 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:58 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:58 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:59 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:52:59 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:00 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:00 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:00 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:01 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:01 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:02 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:02 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:02 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:03 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:03 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:03 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:27 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:28 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:28 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:28 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:31 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:32 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:53:32 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:54:15 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:54:39 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:55:16 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:55:17 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:55:17 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:55:18 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:55:18 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:55:18 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:55:29 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 17:55:31 --> Severity: Error --> Call to undefined function dr_templates_url() D:\UPUPW_K2.1_64\htdocs\plants\cache\templates\templates.pc.default.common.header.html.cache.php 73
ERROR - 2017-08-07 19:04:29 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:05:28 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:39 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:48 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:49 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:49 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:50 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:50 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:50 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:50 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:50 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:51 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:51 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:51 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:51 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:51 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:52 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
ERROR - 2017-08-07 19:07:58 --> Severity: Error --> Call to undefined method Search::post() D:\UPUPW_K2.1_64\htdocs\plants\finecms\dayrui\controllers\Search.php 59
