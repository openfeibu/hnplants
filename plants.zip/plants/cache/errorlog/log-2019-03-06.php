<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-06 10:07:47 --> Severity: Error --> Maximum execution time of 100 seconds exceeded C:\WWW\plants\finecms\system\libraries\Session\drivers\Session_files_driver.php 178
ERROR - 2019-03-06 10:07:47 --> Severity: Error --> Maximum execution time of 100 seconds exceeded C:\WWW\plants\finecms\system\libraries\Session\drivers\Session_files_driver.php 178
ERROR - 2019-03-06 10:07:47 --> Severity: Error --> Maximum execution time of 100 seconds exceeded C:\WWW\plants\finecms\system\libraries\Session\drivers\Session_files_driver.php 178
ERROR - 2019-03-06 10:08:08 --> Severity: Error --> Maximum execution time of 100 seconds exceeded C:\WWW\plants\finecms\system\libraries\Session\drivers\Session_files_driver.php 178
ERROR - 2019-03-06 22:41:01 --> Cache: Failed to create Memcache(d) object; extension not loaded?
