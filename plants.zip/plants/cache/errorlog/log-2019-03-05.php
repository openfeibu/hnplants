<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-05 22:24:19 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2019-03-05 22:24:44 --> Cache: Failed to create Memcache(d) object; extension not loaded?
