<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-08 13:23:07 --> Unable to connect to the database
ERROR - 2017-08-08 15:22:25 --> Severity: Error --> Maximum execution time of 100 seconds exceeded D:\UPUPW_K2.1\htdocs\school_project\plants\finecms\system\libraries\Session\drivers\Session_files_driver.php 178
ERROR - 2017-08-08 15:22:25 --> Severity: Error --> Maximum execution time of 100 seconds exceeded D:\UPUPW_K2.1\htdocs\school_project\plants\finecms\system\libraries\Session\drivers\Session_files_driver.php 178
