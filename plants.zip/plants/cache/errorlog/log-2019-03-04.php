<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-04 12:31:59 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:21 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:21 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:22 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:22 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:25 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:25 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:26 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:26 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:26 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:27 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:27 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:27 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:27 --> Unable to connect to the database
ERROR - 2019-03-04 12:36:27 --> Unable to connect to the database
ERROR - 2019-03-04 18:00:39 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2019-03-04 18:17:33 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2019-03-04 18:18:09 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2019-03-04 18:20:55 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2019-03-04 18:21:32 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2019-03-04 18:22:24 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2019-03-04 18:23:23 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2019-03-04 18:23:42 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2019-03-04 18:24:06 --> Cache: Failed to create Memcache(d) object; extension not loaded?
ERROR - 2019-03-04 18:24:34 --> Cache: Failed to create Memcache(d) object; extension not loaded?
