<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

$config = array(
	'default' => array(
		'hostname' => '',
		'port'     => '',
		'weight'   => '1',
	),
);
