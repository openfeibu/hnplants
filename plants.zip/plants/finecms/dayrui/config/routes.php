<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');


/**
 * 默认路由配置（不允许更改）
 */

$routes['test'] = 'api/test';
$routes['sitemap.xml'] = 'api/sitemap';

